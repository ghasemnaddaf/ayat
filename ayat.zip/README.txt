If you have a website and would like to view in it a random Aya from the Holy Quran on every page refresh, 
you can copy-paste the code in the "ayat_client.heml" file into your HTML (under <body>).
 
Alternatively, you can use the attached file, standalone, as the "home page" of your browsers.

The Ayas are retrieved from the file provided by Tanzil Project: http://Tanzil.net to ensure accuracy.

The server code is in ayat.php. It is currently running on http://ayat.freehostingcloud.com/cgi-bin/ayat.php

Sample:  http://ayat.freehostingcloud.com/ayat_client.html

Eltemase 2A
ghasem.naddaf@gmail.com